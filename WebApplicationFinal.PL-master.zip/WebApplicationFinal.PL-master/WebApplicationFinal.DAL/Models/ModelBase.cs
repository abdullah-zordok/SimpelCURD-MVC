﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplicationFinal.DAL.Models
{
    public class ModelBase
    {
        public int Id { get; set; }
    }
}
