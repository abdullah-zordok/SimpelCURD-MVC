﻿namespace DEMO.PL.Models
{
    public class UsersInRoleViewModel
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public bool IsSelected { get; set; }
    }
}
